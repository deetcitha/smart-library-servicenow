"""Integration tests for the workflow"""

import unittest
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, User, WorkflowStatus, UserRole
from services import RequestService, UserService, AnalyticsService
from workflows import RequestWorkflow


class TestWorkflowIntegration(unittest.TestCase):
    """Integration tests for complete workflow"""
    
    def setUp(self):
        """Set up test environment"""
        engine = create_engine('sqlite:///:memory:')
        Base.metadata.create_all(engine)
        self.Session = sessionmaker(bind=engine)
        self.session = self.Session()
        
        # Create test users
        self.user_service = UserService(self.session)
        
        self.requester = self.user_service.create_user(
            username='requester1',
            email='requester@library.com',
            full_name='Test Requester',
            role=UserRole.REQUESTER
        )
        
        self.approver = self.user_service.create_user(
            username='approver1',
            email='approver@library.com',
            full_name='Test Approver',
            role=UserRole.APPROVER
        )
        
        self.request_service = RequestService(self.session)
        self.analytics_service = AnalyticsService(self.session)
    
    def tearDown(self):
        """Clean up"""
        self.session.close()
    
    def test_complete_workflow(self):
        """Test complete request workflow"""
        
        # 1. Create request
        request = self.request_service.create_request(
            requester_id=self.requester.id,
            title='Multi-Volume Encyclopedia Set',
            description='Complete reference collection',
            priority=2,
            budget=10000,
            department='Reference'
        )
        
        # 2. Add items
        for i in range(1, 4):
            self.request_service.add_item_to_request(
                request_id=request.id,
                title=f'Encyclopedia Volume {i}',
                item_type='book',
                author='Publisher',
                quantity=2,
                unit_cost=1500
            )
        
        # 3. Submit request
        self.request_service.submit_request(request.id, self.requester.id)
        
        # Verify pending approval status (due to budget threshold)
        updated_req = self.request_service.get_request(request.id)
        self.assertEqual(updated_req.status, WorkflowStatus.PENDING_APPROVAL)
        
        # 4. Approve request
        self.request_service.approve_request(
            request.id,
            self.approver.id,
            comments='Approved - good value'
        )
        
        # Verify approved status
        updated_req = self.request_service.get_request(request.id)
        self.assertEqual(updated_req.status, WorkflowStatus.APPROVED)
        
        # 5. Complete request
        self.request_service.complete_request(request.id)
        
        # Verify completed status
        updated_req = self.request_service.get_request(request.id)
        self.assertEqual(updated_req.status, WorkflowStatus.COMPLETED)
        self.assertIsNotNone(updated_req.completed_at)
    
    def test_rejection_workflow(self):
        """Test request rejection and resubmission"""
        
        # Create and submit request that needs approval
        request = self.request_service.create_request(
            requester_id=self.requester.id,
            title='Test Request',
            description='Test',
            priority=1  # High priority - requires approval
        )
        
        self.request_service.add_item_to_request(
            request_id=request.id,
            title='Test Item',
            item_type='book'
        )
        
        self.request_service.submit_request(request.id, self.requester.id)
        
        # Reject request
        self.request_service.reject_request(
            request.id,
            self.approver.id,
            comments='Needs more justification'
        )
        
        # Verify rejected status
        updated_req = self.request_service.get_request(request.id)
        self.assertEqual(updated_req.status, WorkflowStatus.REJECTED)
    
    def test_analytics(self):
        """Test analytics generation"""
        
        # Create multiple requests with different statuses
        for i in range(3):
            request = self.request_service.create_request(
                requester_id=self.requester.id,
                title=f'Request {i}',
                description='Test'
            )
            self.request_service.add_item_to_request(
                request_id=request.id,
                title='Item',
                item_type='book'
            )
            self.request_service.submit_request(request.id, self.requester.id)
        
        # Get analytics
        summary = self.analytics_service.get_requests_summary()
        
        self.assertGreater(summary['total_requests'], 0)
        self.assertGreater(summary['total_items'], 0)


if __name__ == '__main__':
    unittest.main()
