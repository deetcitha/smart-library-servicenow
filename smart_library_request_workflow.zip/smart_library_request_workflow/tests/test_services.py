"""Unit tests for request service"""

import unittest
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, User, Request, UserRole, WorkflowStatus
from services import RequestService
from workflows import RequestWorkflow


class TestRequestService(unittest.TestCase):
    """Test cases for RequestService"""
    
    def setUp(self):
        """Set up test database"""
        engine = create_engine('sqlite:///:memory:')
        Base.metadata.create_all(engine)
        self.Session = sessionmaker(bind=engine)
        self.session = self.Session()
        
        # Create test user
        self.test_user = User(
            username='testuser',
            email='test@library.com',
            full_name='Test User',
            role=UserRole.REQUESTER
        )
        self.session.add(self.test_user)
        self.session.commit()
        
        self.service = RequestService(self.session)
    
    def tearDown(self):
        """Clean up"""
        self.session.close()
    
    def test_create_request(self):
        """Test creating a request"""
        request = self.service.create_request(
            requester_id=self.test_user.id,
            title='Test Request',
            description='Test Description',
            priority=2,
            budget=5000
        )
        
        self.assertIsNotNone(request.id)
        self.assertEqual(request.title, 'Test Request')
        self.assertEqual(request.status, WorkflowStatus.DRAFT)
        self.assertTrue(request.request_number.startswith('REQ-'))
    
    def test_add_item_to_request(self):
        """Test adding items to request"""
        request = self.service.create_request(
            requester_id=self.test_user.id,
            title='Test Request',
            description='Test'
        )
        
        item = self.service.add_item_to_request(
            request_id=request.id,
            title='Test Book',
            item_type='book',
            author='Test Author',
            quantity=2,
            unit_cost=25
        )
        
        self.assertIsNotNone(item.id)
        self.assertEqual(item.title, 'Test Book')
        self.assertEqual(item.quantity, 2)
    
    def test_submit_request(self):
        """Test submitting a request"""
        request = self.service.create_request(
            requester_id=self.test_user.id,
            title='Test Request',
            description='Test'
        )
        
        # Add item
        self.service.add_item_to_request(
            request_id=request.id,
            title='Test Book',
            item_type='book'
        )
        
        # Submit request
        self.service.submit_request(request.id, self.test_user.id)
        
        # Verify status changed
        updated_request = self.service.get_request(request.id)
        self.assertNotEqual(updated_request.status, WorkflowStatus.DRAFT)
        self.assertIsNotNone(updated_request.submitted_at)


class TestWorkflow(unittest.TestCase):
    """Test cases for workflow logic"""
    
    def setUp(self):
        """Set up workflow engine"""
        self.workflow = RequestWorkflow()
    
    def test_valid_transitions(self):
        """Test valid state transitions"""
        self.assertTrue(self.workflow.can_transition('draft', 'submitted'))
        self.assertTrue(self.workflow.can_transition('submitted', 'pending_approval'))
        self.assertTrue(self.workflow.can_transition('pending_approval', 'approved'))
    
    def test_invalid_transitions(self):
        """Test invalid state transitions"""
        self.assertFalse(self.workflow.can_transition('draft', 'completed'))
        self.assertFalse(self.workflow.can_transition('completed', 'draft'))
    
    def test_approval_evaluation(self):
        """Test approval requirement evaluation"""
        # Should require approval - high item count
        result = self.workflow.evaluate_request_for_approval(
            total_items=6,
            budget=3000,
            priority=3
        )
        self.assertTrue(result)
        
        # Should require approval - high priority
        result = self.workflow.evaluate_request_for_approval(
            total_items=2,
            budget=3000,
            priority=1
        )
        self.assertTrue(result)
        
        # Should not require approval
        result = self.workflow.evaluate_request_for_approval(
            total_items=2,
            budget=500,
            priority=3
        )
        self.assertFalse(result)


if __name__ == '__main__':
    unittest.main()
