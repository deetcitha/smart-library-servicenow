"""Test module initialization"""
