"""Utility functions"""

from datetime import datetime
import json


def to_iso_format(dt: datetime) -> str:
    """Convert datetime to ISO format string"""
    if dt is None:
        return None
    return dt.isoformat()


def format_request_for_output(request) -> dict:
    """Format request object for JSON output"""
    return {
        'id': request.id,
        'request_number': request.request_number,
        'title': request.title,
        'description': request.description,
        'status': request.status.value,
        'priority': request.priority,
        'budget': request.budget,
        'department': request.department,
        'requester_id': request.requester_id,
        'items_count': len(request.items),
        'created_at': to_iso_format(request.created_at),
        'submitted_at': to_iso_format(request.submitted_at),
        'completed_at': to_iso_format(request.completed_at),
        'updated_at': to_iso_format(request.updated_at)
    }


def format_user_for_output(user) -> dict:
    """Format user object for JSON output"""
    return {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'full_name': user.full_name,
        'role': user.role.value,
        'department': user.department,
        'is_active': user.is_active,
        'created_at': to_iso_format(user.created_at)
    }


class ValidationError(Exception):
    """Custom validation error"""
    pass


def validate_request_data(data: dict) -> bool:
    """Validate request creation data"""
    required_fields = ['requester_id', 'title']
    
    for field in required_fields:
        if field not in data or not data[field]:
            raise ValidationError(f"Missing required field: {field}")
    
    return True


def validate_priority(priority: int) -> bool:
    """Validate priority value"""
    if priority not in range(1, 6):
        raise ValidationError("Priority must be between 1 and 5")
    return True
