"""Smart Library Request Workflow Application"""

__version__ = "1.0.0"
__author__ = "Library Services"
