"""REST API Routes for Smart Library Request Workflow"""

from flask import Blueprint, request, jsonify, g
from services import RequestService, UserService, AnalyticsService
from models import WorkflowStatus, UserRole

# Create blueprint
api_bp = Blueprint('api', __name__, url_prefix='/api/v1')


def get_db():
    """Get database session from g object"""
    return g.get('db')


# ============================================================================
# REQUEST ENDPOINTS
# ============================================================================

@api_bp.route('/requests', methods=['POST'])
def create_request():
    """Create a new request"""
    try:
        db = get_db()
        data = request.get_json()
        
        req_service = RequestService(db)
        new_request = req_service.create_request(
            requester_id=data['requester_id'],
            title=data['title'],
            description=data.get('description'),
            priority=data.get('priority', 3),
            department=data.get('department'),
            budget=data.get('budget', 0)
        )
        
        return {
            'status': 'success',
            'message': 'Request created',
            'request_id': new_request.id,
            'request_number': new_request.request_number
        }, 201
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/<int:request_id>', methods=['GET'])
def get_request_detail(request_id: int):
    """Get request details"""
    try:
        db = get_db()
        req_service = RequestService(db)
        req = req_service.get_request(request_id)
        
        if not req:
            return {'status': 'error', 'message': 'Request not found'}, 404
        
        return {
            'status': 'success',
            'request': {
                'id': req.id,
                'request_number': req.request_number,
                'title': req.title,
                'status': req.status.value,
                'priority': req.priority,
                'budget': req.budget,
                'items_count': len(req.items),
                'created_at': req.created_at.isoformat(),
                'submitted_at': req.submitted_at.isoformat() if req.submitted_at else None
            }
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/<int:request_id>/items', methods=['POST'])
def add_request_item(request_id: int):
    """Add item to request"""
    try:
        db = get_db()
        data = request.get_json()
        
        req_service = RequestService(db)
        item = req_service.add_item_to_request(
            request_id=request_id,
            title=data['title'],
            item_type=data['item_type'],
            author=data.get('author'),
            isbn=data.get('isbn'),
            quantity=data.get('quantity', 1),
            unit_cost=data.get('unit_cost', 0),
            justification=data.get('justification')
        )
        
        return {
            'status': 'success',
            'message': 'Item added',
            'item_id': item.id
        }, 201
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/<int:request_id>/submit', methods=['POST'])
def submit_request_api(request_id: int):
    """Submit request for processing"""
    try:
        db = get_db()
        data = request.get_json()
        
        req_service = RequestService(db)
        req_service.submit_request(request_id, data['submitted_by_id'])
        
        return {
            'status': 'success',
            'message': 'Request submitted'
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/<int:request_id>/approve', methods=['POST'])
def approve_request_api(request_id: int):
    """Approve a request"""
    try:
        db = get_db()
        data = request.get_json()
        
        req_service = RequestService(db)
        req_service.approve_request(
            request_id,
            data['approver_id'],
            data.get('comments')
        )
        
        return {
            'status': 'success',
            'message': 'Request approved'
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/<int:request_id>/reject', methods=['POST'])
def reject_request_api(request_id: int):
    """Reject a request"""
    try:
        db = get_db()
        data = request.get_json()
        
        req_service = RequestService(db)
        req_service.reject_request(
            request_id,
            data['approver_id'],
            data.get('comments')
        )
        
        return {
            'status': 'success',
            'message': 'Request rejected'
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/<int:request_id>/complete', methods=['POST'])
def complete_request_api(request_id: int):
    """Mark request as completed"""
    try:
        db = get_db()
        req_service = RequestService(db)
        req_service.complete_request(request_id)
        
        return {
            'status': 'success',
            'message': 'Request completed'
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/requests/status/<status>', methods=['GET'])
def get_requests_by_status_route(status: str):
    """Get requests by status"""
    try:
        db = get_db()
        req_service = RequestService(db)
        requests = req_service.get_requests_by_status(WorkflowStatus[status.upper()])
        
        return {
            'status': 'success',
            'requests': [
                {
                    'id': r.id,
                    'request_number': r.request_number,
                    'title': r.title,
                    'status': r.status.value
                }
                for r in requests
            ]
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


# ============================================================================
# USER ENDPOINTS
# ============================================================================

@api_bp.route('/users', methods=['POST'])
def create_user_api():
    """Create new user"""
    try:
        db = get_db()
        data = request.get_json()
        
        user_service = UserService(db)
        user = user_service.create_user(
            username=data['username'],
            email=data['email'],
            full_name=data['full_name'],
            role=UserRole[data.get('role', 'REQUESTER')],
            department=data.get('department')
        )
        
        return {
            'status': 'success',
            'message': 'User created',
            'user_id': user.id
        }, 201
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user_api(user_id: int):
    """Get user details"""
    try:
        db = get_db()
        user_service = UserService(db)
        user = user_service.get_user(user_id)
        
        if not user:
            return {'status': 'error', 'message': 'User not found'}, 404
        
        return {
            'status': 'success',
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'full_name': user.full_name,
                'role': user.role.value,
                'department': user.department,
                'is_active': user.is_active
            }
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


# ============================================================================
# ANALYTICS ENDPOINTS
# ============================================================================

@api_bp.route('/analytics/summary', methods=['GET'])
def get_analytics_summary():
    """Get analytics summary"""
    try:
        db = get_db()
        analytics_service = AnalyticsService(db)
        summary = analytics_service.get_requests_summary()
        
        return {
            'status': 'success',
            'summary': summary
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


@api_bp.route('/analytics/status-breakdown', methods=['GET'])
def get_status_breakdown():
    """Get request status breakdown"""
    try:
        db = get_db()
        analytics_service = AnalyticsService(db)
        breakdown = analytics_service.get_requests_by_status_count()
        
        return {
            'status': 'success',
            'breakdown': breakdown
        }, 200
    
    except Exception as e:
        return {'status': 'error', 'message': str(e)}, 400


def register_api_routes(app, db_session_factory):
    """Register API routes with Flask app"""
    
    # Add database session to g object for each request
    @app.before_request
    def before_request():
        g.db = db_session_factory()
    
    @app.teardown_appcontext
    def teardown_db(exception):
        db = g.pop('db', None)
        if db is not None:
            db.close()
    
    # Register blueprints
    app.register_blueprint(api_bp)
