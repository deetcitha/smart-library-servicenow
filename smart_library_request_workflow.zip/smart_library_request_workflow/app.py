"""Main Application Entry Point"""

from flask import Flask, render_template
from config import config
from database import init_db
import os


def create_app(config_name: str = None) -> Flask:
    """
    Application factory function
    
    Args:
        config_name: Configuration environment (development, testing, production)
        
    Returns:
        Flask application instance
    """
    
    # Determine configuration
    if config_name is None:
        config_name = os.getenv('FLASK_ENV', 'development')
    
    cfg = config.get(config_name) or config['default']
    
    # Create Flask app
    app = Flask(__name__)
    app.config.from_object(cfg)
    
    # Initialize database
    engine, SessionLocal = init_db(app.config['SQLALCHEMY_DATABASE_URI'])
    
    # Store session factory for later use
    app.SessionLocal = SessionLocal
    
    # Import and register API routes
    from api import register_api_routes
    register_api_routes(app, SessionLocal)
    
    # Web UI routes
    @app.route('/', methods=['GET'])
    def index():
        return render_template('index.html')
    
    # Health check endpoint
    @app.route('/health', methods=['GET'])
    def health_check():
        return {'status': 'healthy', 'service': 'Smart Library Request Workflow'}, 200
    
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
