"""Analytics and Reporting Services"""

from sqlalchemy.orm import Session
from sqlalchemy import func
from models import Request, RequestItem, WorkflowStatus, User, UserRole
from typing import Dict, List, Tuple


class AnalyticsService:
    """Service for request analytics and reporting"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def get_requests_by_status_count(self) -> Dict[str, int]:
        """Get count of requests by status"""
        results = self.db.query(
            Request.status,
            func.count(Request.id)
        ).group_by(Request.status).all()
        
        return {str(status): count for status, count in results}
    
    def get_total_budget_by_department(self) -> Dict[str, int]:
        """Get total budget requests by department"""
        results = self.db.query(
            Request.department,
            func.sum(Request.budget)
        ).group_by(Request.department).all()
        
        return {dept: total for dept, total in results if dept}
    
    def get_average_request_value(self) -> float:
        """Get average budget per request"""
        result = self.db.query(func.avg(Request.budget)).scalar()
        return result or 0.0
    
    def get_top_requesters(self, limit: int = 10) -> List[Tuple[str, int]]:
        """Get top requesters by number of requests"""
        results = self.db.query(
            User.username,
            func.count(Request.id)
        ).join(Request).group_by(User.id).order_by(
            func.count(Request.id).desc()
        ).limit(limit).all()
        
        return results
    
    def get_approval_rate(self) -> float:
        """Get percentage of approved requests"""
        total = self.db.query(func.count(Request.id)).scalar()
        approved = self.db.query(func.count(Request.id)).filter(
            Request.status == WorkflowStatus.APPROVED
        ).scalar()
        
        if total == 0:
            return 0.0
        return (approved / total) * 100
    
    def get_pending_requests_count(self) -> int:
        """Get count of pending requests"""
        return self.db.query(func.count(Request.id)).filter(
            Request.status == WorkflowStatus.PENDING_APPROVAL
        ).scalar() or 0
    
    def get_requests_summary(self) -> Dict:
        """Get comprehensive request summary"""
        return {
            'total_requests': self.db.query(func.count(Request.id)).scalar() or 0,
            'pending_approval': self.get_pending_requests_count(),
            'approved': self.db.query(func.count(Request.id)).filter(
                Request.status == WorkflowStatus.APPROVED
            ).scalar() or 0,
            'completed': self.db.query(func.count(Request.id)).filter(
                Request.status == WorkflowStatus.COMPLETED
            ).scalar() or 0,
            'rejected': self.db.query(func.count(Request.id)).filter(
                Request.status == WorkflowStatus.REJECTED
            ).scalar() or 0,
            'approval_rate': self.get_approval_rate(),
            'total_items': self.db.query(func.count(RequestItem.id)).scalar() or 0,
            'average_request_value': self.get_average_request_value()
        }
    
    def get_items_per_request_average(self) -> float:
        """Get average number of items per request"""
        result = self.db.query(func.avg(func.count(RequestItem.id))).group_by(
            RequestItem.request_id
        ).scalar()
        return result or 0.0
