"""User Management Services"""

from sqlalchemy.orm import Session
from models import User, UserRole
from typing import Optional, List


class UserService:
    """Service for managing users"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def create_user(self, username: str, email: str, full_name: str,
                   role: UserRole = UserRole.REQUESTER, department: str = None) -> User:
        """Create a new user"""
        user = User(
            username=username,
            email=email,
            full_name=full_name,
            role=role,
            department=department
        )
        self.db.add(user)
        self.db.commit()
        return user
    
    def get_user(self, user_id: int) -> Optional[User]:
        """Get user by ID"""
        return self.db.query(User).filter(User.id == user_id).first()
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username"""
        return self.db.query(User).filter(User.username == username).first()
    
    def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email"""
        return self.db.query(User).filter(User.email == email).first()
    
    def get_users_by_role(self, role: UserRole) -> List[User]:
        """Get all users with a specific role"""
        return self.db.query(User).filter(User.role == role).all()
    
    def get_active_users(self) -> List[User]:
        """Get all active users"""
        return self.db.query(User).filter(User.is_active == True).all()
    
    def deactivate_user(self, user_id: int) -> bool:
        """Deactivate a user"""
        user = self.get_user(user_id)
        if user:
            user.is_active = False
            self.db.commit()
            return True
        return False
    
    def activate_user(self, user_id: int) -> bool:
        """Activate a user"""
        user = self.get_user(user_id)
        if user:
            user.is_active = True
            self.db.commit()
            return True
        return False
    
    def update_user_role(self, user_id: int, new_role: UserRole) -> bool:
        """Update user role"""
        user = self.get_user(user_id)
        if user:
            user.role = new_role
            self.db.commit()
            return True
        return False
