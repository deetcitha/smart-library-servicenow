"""Request Management Services"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from models import Request, RequestItem, User, Approval, RequestNote, WorkflowStatus, UserRole
from workflows import RequestWorkflow, WorkflowEngine
import uuid


class RequestService:
    """Service for managing library requests"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
        self.workflow_engine = WorkflowEngine()
    
    def create_request(self, requester_id: int, title: str, description: str,
                      priority: int = 3, department: str = None, budget: int = 0) -> Request:
        """Create a new request"""
        request_number = f"REQ-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
        
        request = Request(
            request_number=request_number,
            requester_id=requester_id,
            title=title,
            description=description,
            priority=priority,
            department=department,
            budget=budget,
            status=WorkflowStatus.DRAFT
        )
        
        self.db.add(request)
        self.db.commit()
        return request
    
    def add_item_to_request(self, request_id: int, title: str, item_type: str,
                           author: str = None, isbn: str = None, quantity: int = 1,
                           unit_cost: int = 0, justification: str = None) -> RequestItem:
        """Add an item to a request"""
        item = RequestItem(
            request_id=request_id,
            title=title,
            item_type=item_type,
            author=author,
            isbn=isbn,
            quantity=quantity,
            unit_cost=unit_cost,
            justification=justification
        )
        
        self.db.add(item)
        self.db.commit()
        return item
    
    def submit_request(self, request_id: int, submitted_by_id: int) -> bool:
        """Submit a request for processing"""
        request = self.db.query(Request).filter(Request.id == request_id).first()
        if not request:
            raise ValueError(f"Request {request_id} not found")
        
        if request.status != WorkflowStatus.DRAFT:
            raise ValueError(f"Cannot submit request with status {request.status}")
        
        if not request.items:
            raise ValueError("Request must contain at least one item")
        
        # Determine if approval is needed
        workflow = RequestWorkflow()
        needs_approval = workflow.evaluate_request_for_approval(
            len(request.items),
            request.budget,
            request.priority
        )
        
        # First transition to SUBMITTED
        request.status = WorkflowStatus.SUBMITTED
        request.submitted_at = datetime.utcnow()
        request.updated_at = datetime.utcnow()
        
        self.db.commit()
        
        # Record first transition
        self.workflow_engine.execute_transition(
            str(request_id),
            WorkflowStatus.DRAFT.value,
            WorkflowStatus.SUBMITTED.value,
            str(submitted_by_id),
            {'total_items': len(request.items)}
        )
        
        # Then determine next state
        if needs_approval:
            request.status = WorkflowStatus.PENDING_APPROVAL
        else:
            request.status = WorkflowStatus.IN_PROGRESS
        
        request.updated_at = datetime.utcnow()
        self.db.commit()
        
        # Record second transition if needed
        self.workflow_engine.execute_transition(
            str(request_id),
            WorkflowStatus.SUBMITTED.value,
            request.status.value,
            str(submitted_by_id),
            {'requires_approval': needs_approval}
        )
        
        return True
    
    def approve_request(self, request_id: int, approver_id: int, comments: str = None) -> bool:
        """Approve a request"""
        request = self.db.query(Request).filter(Request.id == request_id).first()
        if not request:
            raise ValueError(f"Request {request_id} not found")
        
        if request.status != WorkflowStatus.PENDING_APPROVAL:
            raise ValueError(f"Request {request_id} cannot be approved in status {request.status}")
        
        # Create approval record
        approval = Approval(
            request_id=request_id,
            approver_id=approver_id,
            status='approved',
            comments=comments,
            approval_date=datetime.utcnow()
        )
        
        request.status = WorkflowStatus.APPROVED
        request.updated_at = datetime.utcnow()
        
        self.db.add(approval)
        self.db.commit()
        
        return True
    
    def reject_request(self, request_id: int, approver_id: int, comments: str = None) -> bool:
        """Reject a request"""
        request = self.db.query(Request).filter(Request.id == request_id).first()
        if not request:
            raise ValueError(f"Request {request_id} not found")
        
        if request.status != WorkflowStatus.PENDING_APPROVAL:
            raise ValueError(f"Request {request_id} cannot be rejected in status {request.status}")
        
        # Create approval record
        approval = Approval(
            request_id=request_id,
            approver_id=approver_id,
            status='rejected',
            comments=comments,
            approval_date=datetime.utcnow()
        )
        
        request.status = WorkflowStatus.REJECTED
        request.updated_at = datetime.utcnow()
        
        self.db.add(approval)
        self.db.commit()
        
        return True
    
    def complete_request(self, request_id: int) -> bool:
        """Mark request as completed"""
        request = self.db.query(Request).filter(Request.id == request_id).first()
        if not request:
            raise ValueError(f"Request {request_id} not found")
        
        request.status = WorkflowStatus.COMPLETED
        request.completed_at = datetime.utcnow()
        request.updated_at = datetime.utcnow()
        
        self.db.commit()
        return True
    
    def cancel_request(self, request_id: int) -> bool:
        """Cancel a request"""
        request = self.db.query(Request).filter(Request.id == request_id).first()
        if not request:
            raise ValueError(f"Request {request_id} not found")
        
        request.status = WorkflowStatus.CANCELLED
        request.updated_at = datetime.utcnow()
        
        self.db.commit()
        return True
    
    def get_request(self, request_id: int) -> Optional[Request]:
        """Retrieve a request by ID"""
        return self.db.query(Request).filter(Request.id == request_id).first()
    
    def get_requests_by_status(self, status: WorkflowStatus) -> List[Request]:
        """Get all requests with a specific status"""
        return self.db.query(Request).filter(Request.status == status).all()
    
    def get_user_requests(self, user_id: int) -> List[Request]:
        """Get all requests from a specific user"""
        return self.db.query(Request).filter(Request.requester_id == user_id).all()
    
    def add_note(self, request_id: int, author_id: int, content: str) -> RequestNote:
        """Add a note to a request"""
        note = RequestNote(
            request_id=request_id,
            author_id=author_id,
            content=content
        )
        self.db.add(note)
        self.db.commit()
        return note
    
    def get_request_approvals(self, request_id: int) -> List[Approval]:
        """Get all approvals for a request"""
        return self.db.query(Approval).filter(Approval.request_id == request_id).all()
