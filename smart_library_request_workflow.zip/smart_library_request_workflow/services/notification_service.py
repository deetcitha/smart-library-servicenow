"""Notification Services for request updates and alerts"""

from typing import List, Optional
from datetime import datetime
from enum import Enum


class NotificationType(Enum):
    """Types of notifications"""
    REQUEST_SUBMITTED = "request_submitted"
    REQUEST_APPROVED = "request_approved"
    REQUEST_REJECTED = "request_rejected"
    REQUEST_COMPLETED = "request_completed"
    APPROVAL_REQUIRED = "approval_required"
    REQUEST_STATUS_CHANGE = "request_status_change"


class Notification:
    """Represents a notification"""
    
    def __init__(self, recipient_email: str, subject: str, body: str,
                 notification_type: NotificationType, related_request_id: int = None):
        self.recipient_email = recipient_email
        self.subject = subject
        self.body = body
        self.notification_type = notification_type
        self.related_request_id = related_request_id
        self.created_at = datetime.utcnow()
        self.sent = False


class NotificationService:
    """Service for handling notifications"""
    
    def __init__(self, enabled: bool = True, admin_email: str = "admin@library.com"):
        self.enabled = enabled
        self.admin_email = admin_email
        self.notifications_queue = []
    
    def send_request_submitted_notification(self, requester_email: str, request_number: str,
                                           request_title: str, request_id: int) -> bool:
        """Notify requester that request was submitted"""
        if not self.enabled:
            return False
        
        subject = f"Library Request {request_number} Submitted"
        body = f"""
Your library request has been submitted successfully.

Request Number: {request_number}
Title: {request_title}

Status: Submitted
Next Steps: Your request will be reviewed by our team.

Thank you for using the Smart Library Request System.
        """
        
        notification = Notification(
            requester_email,
            subject,
            body,
            NotificationType.REQUEST_SUBMITTED,
            request_id
        )
        self._queue_notification(notification)
        return True
    
    def send_approval_required_notification(self, approver_emails: List[str],
                                           request_number: str, request_title: str,
                                           request_id: int) -> bool:
        """Notify approvers that approval is needed"""
        if not self.enabled:
            return False
        
        subject = f"Library Request {request_number} Awaiting Approval"
        body = f"""
A new library request requires your approval.

Request Number: {request_number}
Title: {request_title}

Please review and approve or reject this request in the system.
        """
        
        for email in approver_emails:
            notification = Notification(
                email,
                subject,
                body,
                NotificationType.APPROVAL_REQUIRED,
                request_id
            )
            self._queue_notification(notification)
        
        return True
    
    def send_request_approved_notification(self, requester_email: str, request_number: str,
                                          request_title: str, request_id: int) -> bool:
        """Notify requester that request was approved"""
        if not self.enabled:
            return False
        
        subject = f"Library Request {request_number} Approved"
        body = f"""
Your library request has been approved!

Request Number: {request_number}
Title: {request_title}

Status: Approved
Our team will now proceed with fulfilling your request.

Thank you for using the Smart Library Request System.
        """
        
        notification = Notification(
            requester_email,
            subject,
            body,
            NotificationType.REQUEST_APPROVED,
            request_id
        )
        self._queue_notification(notification)
        return True
    
    def send_request_rejected_notification(self, requester_email: str, request_number: str,
                                          request_title: str, reason: str,
                                          request_id: int) -> bool:
        """Notify requester that request was rejected"""
        if not self.enabled:
            return False
        
        subject = f"Library Request {request_number} Rejected"
        body = f"""
Your library request has been rejected.

Request Number: {request_number}
Title: {request_title}

Status: Rejected
Reason: {reason}

You can resubmit your request with modifications if needed.

Thank you for using the Smart Library Request System.
        """
        
        notification = Notification(
            requester_email,
            subject,
            body,
            NotificationType.REQUEST_REJECTED,
            request_id
        )
        self._queue_notification(notification)
        return True
    
    def _queue_notification(self, notification: Notification) -> None:
        """Add notification to queue for sending"""
        self.notifications_queue.append(notification)
    
    def get_pending_notifications(self) -> List[Notification]:
        """Get all notifications waiting to be sent"""
        return [n for n in self.notifications_queue if not n.sent]
    
    def mark_notification_sent(self, notification: Notification) -> None:
        """Mark notification as sent"""
        notification.sent = True
    
    def flush_notifications(self) -> int:
        """Flush all pending notifications (simulate sending)"""
        count = 0
        for notification in self.get_pending_notifications():
            # In a real system, this would send via email service
            print(f"[NOTIFICATION] To: {notification.recipient_email}")
            print(f"Subject: {notification.subject}")
            print(f"Body: {notification.body}")
            print("-" * 80)
            self.mark_notification_sent(notification)
            count += 1
        return count
