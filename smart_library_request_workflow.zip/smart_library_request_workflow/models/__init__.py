"""Database Models for Smart Library Request Workflow"""

from datetime import datetime
from sqlalchemy import Column, String, Integer, Text, DateTime, Boolean, ForeignKey, Enum
from sqlalchemy.orm import relationship
from database import Base
import enum


class UserRole(enum.Enum):
    """User roles in the system"""
    ADMIN = "admin"
    LIBRARIAN = "librarian"
    REQUESTER = "requester"
    APPROVER = "approver"


class WorkflowStatus(enum.Enum):
    """Workflow status states"""
    DRAFT = "draft"
    SUBMITTED = "submitted"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class User(Base):
    """User model"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    full_name = Column(String(200), nullable=False)
    role = Column(Enum(UserRole), default=UserRole.REQUESTER)
    department = Column(String(100))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    requests = relationship("Request", back_populates="requester")
    approvals = relationship("Approval", back_populates="approver")
    
    def __repr__(self):
        return f"<User {self.username}>"


class Request(Base):
    """Library Request model"""
    __tablename__ = 'requests'
    
    id = Column(Integer, primary_key=True)
    request_number = Column(String(50), unique=True, nullable=False)
    requester_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    status = Column(Enum(WorkflowStatus), default=WorkflowStatus.DRAFT)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    priority = Column(Integer, default=3)  # 1=highest, 5=lowest
    department = Column(String(100))
    budget = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    submitted_at = Column(DateTime)
    completed_at = Column(DateTime)
    
    # Relationships
    requester = relationship("User", back_populates="requests")
    items = relationship("RequestItem", back_populates="request", cascade="all, delete-orphan")
    approvals = relationship("Approval", back_populates="request", cascade="all, delete-orphan")
    notes = relationship("RequestNote", back_populates="request", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Request {self.request_number}>"


class RequestItem(Base):
    """Individual item in a library request"""
    __tablename__ = 'request_items'
    
    id = Column(Integer, primary_key=True)
    request_id = Column(Integer, ForeignKey('requests.id'), nullable=False)
    item_type = Column(String(50))  # e.g., book, journal, database
    title = Column(String(300), nullable=False)
    author = Column(String(200))
    isbn = Column(String(20))
    quantity = Column(Integer, default=1)
    unit_cost = Column(Integer, default=0)
    justification = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    request = relationship("Request", back_populates="items")
    
    def __repr__(self):
        return f"<RequestItem {self.title}>"


class Approval(Base):
    """Approval workflow model"""
    __tablename__ = 'approvals'
    
    id = Column(Integer, primary_key=True)
    request_id = Column(Integer, ForeignKey('requests.id'), nullable=False)
    approver_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    status = Column(String(20), default='pending')  # pending, approved, rejected
    comments = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    approval_date = Column(DateTime)
    
    # Relationships
    request = relationship("Request", back_populates="approvals")
    approver = relationship("User", back_populates="approvals")
    
    def __repr__(self):
        return f"<Approval request_id={self.request_id} status={self.status}>"


class RequestNote(Base):
    """Notes and comments on requests"""
    __tablename__ = 'request_notes'
    
    id = Column(Integer, primary_key=True)
    request_id = Column(Integer, ForeignKey('requests.id'), nullable=False)
    author_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    request = relationship("Request", back_populates="notes")
    author = relationship("User")
    
    def __repr__(self):
        return f"<RequestNote request_id={self.request_id}>"
